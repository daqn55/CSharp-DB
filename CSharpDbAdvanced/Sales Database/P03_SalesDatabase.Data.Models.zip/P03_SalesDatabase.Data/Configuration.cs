﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        public static string ConectionString = @"Server=DESKTOP-56432TS\SQLEXPRESS;Database=Sales;Integrated Security=True";
    }
}
