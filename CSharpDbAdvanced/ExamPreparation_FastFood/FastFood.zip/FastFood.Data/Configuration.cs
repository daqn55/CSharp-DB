namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=DESKTOP-56432TS\SQLEXPRESS;Database=FastFood;Trusted_Connection=True";
	}
}