﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    class Configuration
    {
        public static string ConectionString = @"Server=DESKTOP-56432TS\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}
